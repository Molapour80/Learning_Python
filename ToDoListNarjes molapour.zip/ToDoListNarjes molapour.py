worked = {}

def display():
    menu = """
    choose the action:
    1. Add work
    2. Edit work
    3. Remove work
    4. Search work
    5. Display All work
    
    7.done work
    8. Exit
    """
    print(menu)

def Add_work(name):
    
    if name in worked :
        print("Id is already exist!")
        return
    else:
        worked[name] = {
             "status" : False,
              "Time" : None        
                      
                      }
    print("Added!!!!")

def Edit(name):
    if name in worked:
        nem_name = input("Enter your new name :").strip()
        if nem_name not in worked:
                i = worked.index(nem_name)
                worked[i] = nem_name
                print("Edit!!") 
        else:
                print("Exit")
    else:
            print("Not Remove") 


def Remove(name):
     if name in worked:
          del worked[name]
          print("Removed!!!!")
     else:
          print("Not found!!!")     

     
def search(name):
    if name in worked:
        i = worked.index(name)
        name = worked[i]
        status = status[i]
        time = time[i]
        print(f"name :{name},Status: {status}, time: {time}")
    else:
        print("Not found!") 

def Displayallwork():   
    for i , Ans in enumerate(worked):
         print(i+1, Ans, status[i], Time[i])    

def Done(name):
    if worked in worked :
            ind = worked.index(worked)
            if status[ind] :
                print(f"task {worked} is alredy True")
            
            else:
                
                start_time = input("enter the time you start: ") 
                end_time = input("enter rhe time you finished: ") 
                
                start_time_parts = start_time.split(":")
                end_time_parts = end_time.split(":")

                start_time_h = int(start_time_parts[0]) 
                start_time_m = int(start_time_parts[1])

                end_time_h = int(end_time_parts[0])
                end_time_m = int(end_time_parts[1])

                time_m = (end_time_h*60+end_time_m) - (start_time_h*60+start_time_m)
                time_h = time_m // 60
                time_m %= 60
                duration = f"{time_h}:{end_time_m}" 

                status[ind] = True
                duration[ind] = duration
    else:
            print(f"task {worked} isnot in the list!")






    








def main():
    while True:
        display()
        c_Action = input("Choose an option: ").strip()
        
        if c_Action == "1":
           name = input("Enter your name :")
           Add_work(name)
        
        elif c_Action =="2":
            name = input("Enter your name :")
            Edit(name)

        elif c_Action == "3":
            name = input("Enter your name :")
            Remove(name)

        elif c_Action == "4":
            name =  input("Enter your name :")
            search(name)
        elif c_Action == "5":
            Displayallwork()

        elif c_Action == "7":
            pass

        elif c_Action == "8":
            break

        elif c_Action == "":
            continue

        else:
            print(" please try again. ")
main()